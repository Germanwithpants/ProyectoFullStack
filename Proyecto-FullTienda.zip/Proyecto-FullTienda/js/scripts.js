document.addEventListener('DOMContentLoaded', () => {

    /* --- Lógica para el panel de ADMINISTRADOR (admin.html) --- */
    const productoForm = document.getElementById('productoForm');
    const listaProductos = document.getElementById('lista-productos');
    const formButton = productoForm ? productoForm.querySelector('button') : null;
    const contentSections = document.querySelectorAll('.dashboard .content-card');
    const navLinks = document.querySelectorAll('.admin-panel aside nav ul li a');
    const logoutLink = document.getElementById('logout-link');
    let productoEnEdicion = null;

    // Funciones para manejar datos en localStorage
    function guardarProductos(productos) {
        localStorage.setItem('productos', JSON.stringify(productos));
    }

    function obtenerProductos() {
        const productosJSON = localStorage.getItem('productos');
        return productosJSON ? JSON.parse(productosJSON) : [];
    }

    function guardarReportes(reportes) {
        localStorage.setItem('reportes', JSON.stringify(reportes));
    }

    function obtenerReportes() {
        const reportesJSON = localStorage.getItem('reportes');
        return reportesJSON ? JSON.parse(reportesJSON) : {};
    }

    function guardarUsuarios(usuarios) {
        localStorage.setItem('usuarios', JSON.stringify(usuarios));
    }

    function obtenerUsuarios() {
        const usuariosJSON = localStorage.getItem('usuarios');
        return usuariosJSON ? JSON.parse(usuariosJSON) : [];
    }

    // Nueva función para obtener y guardar el usuario logueado
    function guardarUsuarioLogueado(usuario) {
        localStorage.setItem('usuarioLogueado', JSON.stringify(usuario));
    }

    function obtenerUsuarioLogueado() {
        const usuarioJSON = localStorage.getItem('usuarioLogueado');
        return usuarioJSON ? JSON.parse(usuarioJSON) : null;
    }
    
    // --- NUEVA LÓGICA: Restablecer el Dashboard ---
    const resetButton = document.getElementById('reset-dashboard-btn');

    if (resetButton) {
        resetButton.addEventListener('click', () => {
            if (confirm('¿Estás seguro de que quieres restablecer todos los datos de ventas y reportes? Esta acción no se puede deshacer.')) {
                
                // Borrar los datos de ventas y reportes
                localStorage.removeItem('reportes');

                // Borrar el carrito del usuario para evitar conflictos
                localStorage.removeItem('carrito');
                
                // Actualizar la vista del dashboard para mostrar 0
                renderizarDashboard();
                
                alert('Los datos del dashboard han sido restablecidos.');
            }
        });
    }

    // --- LÓGICA EXISTENTE ---
    function renderizarDashboard() {
        const reportes = obtenerReportes();
        const usuarios = obtenerUsuarios();
        const historialVentas = reportes.historialVentas || [];

        // Calcular clientes únicos que han comprado
        const compradores = new Set(historialVentas.map(orden => orden.usuario));
        compradores.delete('Invitado'); // No contar compras de invitados

        // Calcular total de productos vendidos
        const productosVendidos = historialVentas.reduce((total, orden) => {
            return total + orden.productos.reduce((sum, p) => sum + p.cantidad, 0);
        }, 0);

        // Actualizar los valores en el dashboard
        document.getElementById('total-ventas').textContent = `$${(reportes.ventasTotales || 0).toFixed(2)}`;
        document.getElementById('clientes-activos').textContent = compradores.size;
        document.getElementById('productos-vendidos').textContent = productosVendidos;
        document.getElementById('total-usuarios').textContent = usuarios.length;
    }

    // Cargar productos al iniciar en Admin
    function renderizarProductosAdmin() {
        const productos = obtenerProductos();
        if (listaProductos) {
            listaProductos.innerHTML = '';
            productos.forEach(producto => {
                const nuevaFila = document.createElement('tr');
                nuevaFila.innerHTML = `
                    <td><img src="${producto.imagen}" alt="${producto.nombre}" style="width: 50px;"></td>
                    <td>${producto.nombre}</td>
                    <td>$${producto.precio.toFixed(2)}</td>
                    <td>${producto.stock}</td>
                    <td>
                        <button class="edit-btn">Editar</button>
                        <button class="delete-btn">Eliminar</button>
                    </td>
                `;
                listaProductos.appendChild(nuevaFila);
            });
        }
    }

    // Lógica de la tabla y formulario de productos
    if (productoForm) {
        productoForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const nombre = document.getElementById('nombre-producto').value;
            const descripcion = document.getElementById('descripcion-producto').value;
            const precio = document.getElementById('precio-producto').value;
            const stock = document.getElementById('stock-producto').value;
            const imagen = document.getElementById('imagen-producto').value;
            let productos = obtenerProductos();

            if (productoEnEdicion) {
                const index = productos.findIndex(p => p.nombre === productoEnEdicion.querySelector('td:nth-child(2)').textContent);
                productos[index] = { nombre, descripcion, precio: parseFloat(precio), stock: parseInt(stock), imagen };
                productoEnEdicion = null;
                formButton.textContent = "Guardar Producto";
            } else {
                productos.push({ nombre, descripcion, precio: parseFloat(precio), stock: parseInt(stock), imagen });
            }
            guardarProductos(productos);
            renderizarProductosAdmin();
            productoForm.reset();
        });
    }

    if (listaProductos) {
        listaProductos.addEventListener('click', (event) => {
            const target = event.target;
            if (target.classList.contains('delete-btn')) {
                const fila = target.closest('tr');
                const nombreProducto = fila.querySelector('td:nth-child(2)').textContent;
                if (confirm(`¿Estás seguro de que quieres eliminar el producto "${nombreProducto}"?`)) {
                    let productos = obtenerProductos();
                    productos = productos.filter(p => p.nombre !== nombreProducto);
                    guardarProductos(productos);
                    fila.remove();
                }
            }
            if (target.classList.contains('edit-btn')) {
                const fila = target.closest('tr');
                const celdas = fila.querySelectorAll('td');
                productoEnEdicion = fila;
                const nombre = celdas[1].textContent;
                const productos = obtenerProductos();
                const productoParaEditar = productos.find(p => p.nombre === nombre);
                const precio = celdas[2].textContent.replace('$', '');
                const stock = celdas[3].textContent;
                const imagenSrc = celdas[0].querySelector('img').src;
                
                document.getElementById('nombre-producto').value = nombre;
                document.getElementById('descripcion-producto').value = productoParaEditar.descripcion || '';
                document.getElementById('precio-producto').value = precio;
                document.getElementById('stock-producto').value = stock;
                const rutaRelativa = imagenSrc.split('/').pop();
                document.getElementById('imagen-producto').value = `img/${rutaRelativa}`;
                formButton.textContent = "Actualizar Producto";
            }
        });
    }
    
    // Lógica para la navegación del panel
    if (navLinks.length > 0) {
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                navLinks.forEach(navLink => navLink.classList.remove('active'));
                e.target.classList.add('active');
                contentSections.forEach(section => section.style.display = 'none');
                const targetId = e.target.getAttribute('href').substring(1);
                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    targetSection.style.display = 'block';
                    if (targetId === 'dashboard') {
                        renderizarDashboard();
                    } else if (targetId === 'reportes') {
                        generarReportes();
                    } else if (targetId === 'gestion-usuarios') {
                        renderizarUsuariosAdmin();
                    }
                }
            });
        });
    }

    // Lógica para el botón de cerrar sesión
    if (logoutLink) {
        logoutLink.addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('isAdminLoggedIn');
            localStorage.removeItem('usuarioLogueado');
            window.location.href = 'index.html';
        });
    }

    // Lógica para los reportes
    function generarReportes() {
        const productos = obtenerProductos();
        const reportes = obtenerReportes();
        const ventasTotales = reportes.ventasTotales || 0;
        const ordenesConcretadas = reportes.ordenesConcretadas || 0;
        const productosPopulares = reportes.productosPopulares || {};
        const listaPopulares = document.querySelector('#reportes #lista-populares');
        const bajoStock = productos.filter(p => p.stock < 10);
        const listaBajoStock = document.querySelector('#reportes #lista-bajo-stock');
        const historialVentas = reportes.historialVentas || [];
        const historialVentasTable = document.getElementById('historial-ventas');

        if (document.querySelector('#reportes #ventas-totales')) {
            document.querySelector('#reportes #ventas-totales').textContent = `$${ventasTotales.toFixed(2)}`;
            document.querySelector('#reportes #ordenes-concretadas').textContent = ordenesConcretadas;
        }

        if (listaPopulares) {
            listaPopulares.innerHTML = '';
            const productosOrdenados = Object.entries(productosPopulares).sort(([, a], [, b]) => b - a);
            productosOrdenados.forEach(([nombre, ventas]) => {
                const li = document.createElement('li');
                li.textContent = `${nombre} (${ventas} ventas)`;
                listaPopulares.appendChild(li);
            });
        }
        
        if (listaBajoStock) {
            listaBajoStock.innerHTML = '';
            if (bajoStock.length > 0) {
                 bajoStock.forEach(p => {
                    const li = document.createElement('li');
                    li.textContent = `${p.nombre} (Stock: ${p.stock})`;
                    listaBajoStock.appendChild(li);
                });
            } else {
                listaBajoStock.innerHTML = '<li>No hay productos con bajo stock.</li>';
            }
        }

        if (historialVentasTable) {
            historialVentasTable.innerHTML = '';
            historialVentas.forEach(orden => {
                const fila = document.createElement('tr');
                const productosTexto = orden.productos.map(p => `${p.nombre} (${p.cantidad})`).join(', ');
                fila.innerHTML = `
                    <td>${orden.id}</td>
                    <td>${orden.usuario}</td>
                    <td>${orden.fecha}</td>
                    <td>${productosTexto}</td>
                    <td>$${orden.total.toFixed(2)}</td>
                `;
                historialVentasTable.appendChild(fila);
            });
        }
    }
    
    // Lógica para la gestión de usuarios
    function renderizarUsuariosAdmin() {
        const usuarios = obtenerUsuarios();
        const historialVentas = (obtenerReportes().historialVentas || []);
        const listaUsuarios = document.getElementById('lista-usuarios');
        
        if (listaUsuarios) {
            listaUsuarios.innerHTML = '';
            usuarios.forEach(usuario => {
                const haComprado = historialVentas.some(orden => orden.usuario === usuario.usuario);
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${usuario.id}</td>
                    <td>${usuario.usuario}</td>
                    <td>${usuario.correo}</td>
                    <td>${haComprado ? 'Sí' : 'No'}</td>
                    <td><button class="ver-historial-btn" data-user="${usuario.usuario}">Ver Historial</button></td>
                `;
                listaUsuarios.appendChild(fila);
            });
        }
    }

    /* --- Lógica de AUTENTICACIÓN (login, register, forgot pass) --- */
    const openLoginBtn = document.getElementById('open-login-btn');
    const loginModal = document.getElementById('login-modal');
    const closeLoginModalBtn = document.getElementById('close-login-modal-btn');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');
    const showForgotPassLink = document.getElementById('show-forgot-pass');
    const showLoginForgotLink = document.getElementById('show-login-forgot');
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');
    const forgotPassSection = document.getElementById('forgot-pass-section');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const forgotPassForm = document.getElementById('forgot-pass-form');

    // Manejar el modal de login
    if (openLoginBtn) {
        openLoginBtn.addEventListener('click', () => {
            loginModal.style.display = 'flex';
        });
    }

    if (closeLoginModalBtn) {
        closeLoginModalBtn.addEventListener('click', () => {
            loginModal.style.display = 'none';
        });
    }

    // Navegar entre secciones del modal
    if (showRegisterLink) {
        showRegisterLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginSection.style.display = 'none';
            registerSection.style.display = 'block';
            forgotPassSection.style.display = 'none';
        });
    }

    if (showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginSection.style.display = 'block';
            registerSection.style.display = 'none';
            forgotPassSection.style.display = 'none';
        });
    }

    if (showForgotPassLink) {
        showForgotPassLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginSection.style.display = 'none';
            registerSection.style.display = 'none';
            forgotPassSection.style.display = 'block';
        });
    }

    if (showLoginForgotLink) {
        showLoginForgotLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginSection.style.display = 'block';
            registerSection.style.display = 'none';
            forgotPassSection.style.display = 'none';
        });
    }

    // Lógica del formulario de login
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('user-login').value;
            const password = document.getElementById('pass-login').value;

            // Validar credenciales de administrador (felipe)
            if (username === 'felipe' && password === 'felipe123') {
                localStorage.setItem('isAdminLoggedIn', 'true');
                window.location.href = 'admin.html';
                return;
            }

            // Validar credenciales de usuario normal
            const usuarios = obtenerUsuarios();
            const usuarioExistente = usuarios.find(u => u.usuario === username && u.clave === password);

            if (usuarioExistente) {
                alert('Inicio de sesión exitoso.');
                guardarUsuarioLogueado(usuarioExistente);
                loginModal.style.display = 'none';
            } else {
                alert('Usuario o contraseña incorrectos.');
            }
        });
    }

    // Lógica del formulario de registro
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const newUser = document.getElementById('new-user').value;
            const newEmail = document.getElementById('new-email').value;
            const newPass = document.getElementById('new-pass').value;
            const confirmPass = document.getElementById('confirm-pass').value;

            if (newPass !== confirmPass) {
                alert('Las claves no coinciden.');
                return;
            }

            let usuarios = obtenerUsuarios();
            const usuarioExistente = usuarios.find(u => u.usuario === newUser || u.correo === newEmail);

            if (usuarioExistente) {
                alert('El usuario o correo ya están registrados.');
            } else {
                const nuevoUsuarioId = usuarios.length > 0 ? Math.max(...usuarios.map(u => u.id)) + 1 : 1;
                usuarios.push({ id: nuevoUsuarioId, usuario: newUser, correo: newEmail, clave: newPass });
                guardarUsuarios(usuarios);
                alert('Cuenta creada con éxito. Ahora puedes iniciar sesión.');
                loginSection.style.display = 'block';
                registerSection.style.display = 'none';
            }
        });
    }

    // Lógica de recuperar contraseña
    if (forgotPassForm) {
        forgotPassForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('forgot-email').value;
            const usuarios = obtenerUsuarios();
            const usuario = usuarios.find(u => u.correo === email);

            if (usuario) {
                const tempPassword = 'clave123';
                alert(`Tu contraseña provisoria es: ${tempPassword}`);
            } else {
                alert('Correo no encontrado.');
            }
        });
    }

    /* --- Lógica para la TIENDA (index.html) --- */
    const productosGrid = document.getElementById('productos-grid');
    const cartSidebar = document.getElementById('cart-sidebar');
    const openCartBtn = document.getElementById('open-cart-btn');
    const closeCartBtn = document.getElementById('close-cart-btn');
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');
    const cartCountElement = document.getElementById('cart-count');
    const checkoutBtn = document.getElementById('checkout-btn');
    const checkoutModal = document.getElementById('checkout-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const emptyCartMessage = document.getElementById('empty-cart-message');
    
    let carrito = obtenerCarrito();

    // Funciones de manejo del carrito
    function guardarCarrito(items) {
        localStorage.setItem('carrito', JSON.stringify(items));
    }
    
    function obtenerCarrito() {
        const carritoJSON = localStorage.getItem('carrito');
        return carritoJSON ? JSON.parse(carritoJSON) : [];
    }

    function renderizarCarrito() {
        cartItemsContainer.innerHTML = '';
        let total = 0;

        if (carrito.length === 0) {
            emptyCartMessage.style.display = 'block';
            checkoutBtn.disabled = true;
        } else {
            emptyCartMessage.style.display = 'none';
            checkoutBtn.disabled = false;
            carrito.forEach(item => {
                const cartItemElement = document.createElement('div');
                cartItemElement.className = 'cart-item';
                cartItemElement.innerHTML = `
                    <img src="${item.imagen}" alt="${item.nombre}">
                    <div class="item-details">
                        <h4>${item.nombre}</h4>
                        <p>${item.cantidad} x $${item.precio.toFixed(2)}</p>
                    </div>
                `;
                cartItemsContainer.appendChild(cartItemElement);
                total += item.precio * item.cantidad;
            });
        }

        cartTotalElement.textContent = `$${total.toFixed(2)}`;
        cartCountElement.textContent = carrito.length;
        guardarCarrito(carrito);
    }
    
    function agregarAlCarrito(productoNombre) {
        const productosDisponibles = obtenerProductos();
        const producto = productosDisponibles.find(p => p.nombre === productoNombre);

        if (producto && producto.stock > 0) {
            const itemExistente = carrito.find(item => item.nombre === productoNombre);
            if (itemExistente) {
                itemExistente.cantidad++;
            } else {
                carrito.push({ ...producto, cantidad: 1 });
            }
            // Reduce el stock del producto
            producto.stock--;
            guardarProductos(productosDisponibles);
            renderizarProductosTienda();
            renderizarCarrito();
        } else {
            alert('Producto agotado');
        }
    }
    
    function manejarCompra() {
        const reportes = obtenerReportes();
        const ventasTotales = carrito.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
        reportes.ventasTotales = (reportes.ventasTotales || 0) + ventasTotales;
        reportes.ordenesConcretadas = (reportes.ordenesConcretadas || 0) + 1;

        // Capturar información del usuario logueado
        const usuarioLogueado = obtenerUsuarioLogueado();
        const nombreUsuario = usuarioLogueado ? usuarioLogueado.usuario : 'Invitado';

        // Actualizar el reporte de productos más populares
        carrito.forEach(item => {
            reportes.productosPopulares = reportes.productosPopulares || {};
            reportes.productosPopulares[item.nombre] = (reportes.productosPopulares[item.nombre] || 0) + item.cantidad;
        });

        // Guardar el historial de la compra
        reportes.historialVentas = reportes.historialVentas || [];
        const nuevoId = reportes.historialVentas.length > 0 ? Math.max(...reportes.historialVentas.map(o => o.id)) + 1 : 1;
        const nuevaOrden = {
            id: nuevoId,
            usuario: nombreUsuario,
            fecha: new Date().toLocaleDateString(),
            productos: carrito.map(p => ({ nombre: p.nombre, cantidad: p.cantidad })),
            total: ventasTotales
        };
        reportes.historialVentas.push(nuevaOrden);

        guardarReportes(reportes);
        
        // Limpiar el carrito después de la compra
        carrito = [];
        guardarCarrito(carrito);
        renderizarCarrito();
    }
    
    // Asignar eventos a los botones
    if (productosGrid) {
        productosGrid.addEventListener('click', (event) => {
            if (event.target.classList.contains('add-to-cart-btn')) {
                const nombreProducto = event.target.dataset.nombre;
                agregarAlCarrito(nombreProducto);
            }
        });
    }

    if (openCartBtn) {
        openCartBtn.addEventListener('click', () => {
            cartSidebar.classList.add('open');
        });
    }

    if (closeCartBtn) {
        closeCartBtn.addEventListener('click', () => {
            cartSidebar.classList.remove('open');
        });
    }

    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            const usuarioLogueado = obtenerUsuarioLogueado();
            if (!usuarioLogueado) {
                alert('Debes iniciar sesión para realizar una compra.');
                loginModal.style.display = 'flex';
                return;
            }
            manejarCompra();
            checkoutModal.style.display = 'flex';
            cartSidebar.classList.remove('open');
        });
    }
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', () => {
            checkoutModal.style.display = 'none';
        });
    }
    
    function renderizarProductosTienda() {
        const productos = obtenerProductos();
        if (productosGrid) {
            productosGrid.innerHTML = '';
            productos.forEach(producto => {
                const productCard = document.createElement('div');
                productCard.className = 'product-card';
                productCard.innerHTML = `
                    <img src="${producto.imagen}" alt="${producto.nombre}">
                    <h3>${producto.nombre}</h3>
                    <p class="description">${producto.descripcion || ''}</p>
                    <p class="price">$${producto.precio.toFixed(2)}</p>
                    <p class="stock">Stock: ${producto.stock}</p>
                    <button class="add-to-cart-btn" data-nombre="${producto.nombre}" ${producto.stock === 0 ? 'disabled' : ''}>Agregar al Carrito</button>
                `;
                productosGrid.appendChild(productCard);
            });
        }
    }

    // --- Inicializar la página (con lógica para cada URL) ---
    if (window.location.pathname.includes('admin.html')) {
        renderizarProductosAdmin();
        renderizarDashboard(); // Llamada a la nueva función
    }
    
    if (window.location.pathname.includes('index.html')) {
        renderizarProductosTienda();
        renderizarCarrito();
    }

});